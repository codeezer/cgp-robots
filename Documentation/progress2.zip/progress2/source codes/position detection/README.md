#Coordinated Gameplaying Robots

## POSITION DETECTION

	For Position Detection, We're using openCV library on Python Programming Language.
